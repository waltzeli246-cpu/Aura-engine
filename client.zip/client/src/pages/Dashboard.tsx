import { StatCard } from "@/components/ui/stat-card";
import { Activity, Box, Layers, Users, Zap, ShieldAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from "recharts";

const performanceData = [
  { time: "0s", physics: 4.2, render: 8.1, scripts: 2.3 },
  { time: "1s", physics: 4.5, render: 8.3, scripts: 2.5 },
  { time: "2s", physics: 4.1, render: 7.9, scripts: 2.2 },
  { time: "3s", physics: 8.5, render: 9.2, scripts: 3.1 }, // Spikes
  { time: "4s", physics: 4.3, render: 8.0, scripts: 2.4 },
  { time: "5s", physics: 4.2, render: 8.1, scripts: 2.3 },
  { time: "6s", physics: 4.0, render: 7.8, scripts: 2.1 },
];

export default function Dashboard() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground glow">System Overview</h2>
          <p className="text-muted-foreground font-sans">Monitoring active engine subsystems</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-green-950/30 border border-green-500/30 px-3 py-1 rounded text-xs font-mono text-green-400">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
            ENGINE ONLINE
          </div>
          <div className="bg-sidebar border border-white/10 px-3 py-1 rounded text-xs font-mono text-muted-foreground">
            v0.9.2-alpha
          </div>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Active Entities"
          value="12,405"
          icon={Box}
          description="Global ECS Count"
          trend="up"
          trendValue="12%"
          color="primary"
        />
        <StatCard
          title="Physics Tick"
          value="8.33ms"
          icon={Zap}
          description="Fixed Step @ 120Hz"
          trend="neutral"
          trendValue="0.01ms"
          color="secondary"
        />
        <StatCard
          title="Net Latency"
          value="42ms"
          icon={Activity}
          description="RTT to Server"
          trend="down"
          trendValue="5ms"
          color="accent"
        />
        <StatCard
          title="Active Bots"
          value="85"
          icon={Users}
          description="AI Agents Logic"
          trend="up"
          trendValue="2"
          color="destructive"
        />
      </div>

      {/* Main Charts Section */}
      <div className="grid gap-4 md:grid-cols-7">
        <Card className="col-span-4 glass-panel cyber-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Frame Timing (ms)
            </CardTitle>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={performanceData}>
                  <defs>
                    <linearGradient id="colorPhysics" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--secondary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--secondary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorRender" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                  <XAxis dataKey="time" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}ms`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '4px' }}
                    itemStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Area type="monotone" dataKey="render" stackId="1" stroke="hsl(var(--primary))" fill="url(#colorRender)" strokeWidth={2} />
                  <Area type="monotone" dataKey="physics" stackId="1" stroke="hsl(var(--secondary))" fill="url(#colorPhysics)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-3 glass-panel cyber-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-accent" />
              Recent Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { time: "10:42:05", level: "WARN", msg: "Physics Spike detected (8.5ms)", type: "Physics" },
                { time: "10:41:22", level: "INFO", msg: "Zone B3_BUNKER loaded (LOD: FULL)", type: "Map" },
                { time: "10:40:15", level: "INFO", msg: "Player joined session (ID: MasterPlayer)", type: "Network" },
                { time: "10:39:55", level: "ERROR", msg: "Texture missing: 'weapon_railgun_diffuse'", type: "Asset" },
                { time: "10:38:10", level: "INFO", msg: "Job System initialized (8 workers)", type: "Core" },
              ].map((log, i) => (
                <div key={i} className="flex items-start gap-3 p-2 rounded hover:bg-white/5 transition-colors border-b border-white/5 last:border-0">
                  <span className="text-xs font-mono text-muted-foreground min-w-[60px]">{log.time}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={cn(
                        "text-[10px] font-bold px-1.5 rounded uppercase",
                        log.level === "WARN" ? "bg-accent/20 text-accent" :
                        log.level === "ERROR" ? "bg-destructive/20 text-destructive" :
                        "bg-primary/20 text-primary"
                      )}>
                        {log.level}
                      </span>
                      <span className="text-xs font-medium text-muted-foreground">[{log.type}]</span>
                    </div>
                    <p className="text-sm font-sans text-foreground">{log.msg}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function cn(...classes: (string | undefined | null | false)[]) {
  return classes.filter(Boolean).join(' ');
}