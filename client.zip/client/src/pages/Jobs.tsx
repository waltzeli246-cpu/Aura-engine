import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, Zap, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

const WORKERS = 8;
const JOB_TYPES = ['PHYSICS', 'AI', 'RENDER', 'STREAM', 'AUDIO'];
const JOB_COLORS = {
  PHYSICS: 'bg-red-500',
  AI: 'bg-purple-500',
  RENDER: 'bg-cyan-500',
  STREAM: 'bg-blue-500',
  AUDIO: 'bg-yellow-500'
};

type Job = {
  id: number;
  type: keyof typeof JOB_COLORS;
  duration: number; // in simulation ticks
  progress: number;
};

export default function Jobs() {
  const [workers, setWorkers] = useState<Array<Job | null>>(Array(WORKERS).fill(null));
  const [queueSize, setQueueSize] = useState(12);
  const [completedJobs, setCompletedJobs] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setWorkers(prevWorkers => {
        return prevWorkers.map(job => {
          if (job) {
            // Process existing job
            if (job.progress >= job.duration) {
              setCompletedJobs(c => c + 1);
              return null; // Job finished
            }
            return { ...job, progress: job.progress + 1 };
          } else {
            // 30% chance to pick up new job if idle
            if (Math.random() < 0.3) {
              const type = JOB_TYPES[Math.floor(Math.random() * JOB_TYPES.length)] as keyof typeof JOB_COLORS;
              return {
                id: Math.random(),
                type,
                duration: 5 + Math.random() * 15,
                progress: 0
              };
            }
            return null;
          }
        });
      });
      
      // Randomly add to queue
      setQueueSize(prev => Math.max(0, prev + (Math.random() > 0.5 ? 1 : -1)));
      
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground glow">Job System</h2>
          <p className="text-muted-foreground font-sans">Multi-Threaded Task Scheduler Status</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-xs text-muted-foreground uppercase">Throughput</div>
            <div className="text-2xl font-mono font-bold text-primary">{(completedJobs / 10).toFixed(1)}/s</div>
          </div>
          <div className="text-right">
             <div className="text-xs text-muted-foreground uppercase">Pending</div>
             <div className="text-2xl font-mono font-bold text-accent">{queueSize}</div>
          </div>
        </div>
      </div>

      <Card className="glass-panel cyber-border p-6">
        <CardHeader className="px-0 pt-0 pb-6">
          <CardTitle className="font-display text-lg flex items-center gap-2">
            <Cpu className="w-5 h-5 text-primary" />
            Worker Threads ({WORKERS})
          </CardTitle>
        </CardHeader>
        <div className="grid grid-cols-8 gap-4 h-[400px]">
          {workers.map((job, i) => (
            <div key={i} className="bg-black/20 rounded-lg border border-white/5 flex flex-col relative overflow-hidden">
              <div className="bg-white/5 p-2 text-center text-xs font-mono text-muted-foreground border-b border-white/5">
                THREAD {i}
              </div>
              
              <div className="flex-1 relative p-1">
                {job ? (
                  <div className={cn(
                    "absolute bottom-0 left-0 right-0 transition-all duration-100 ease-linear",
                    JOB_COLORS[job.type],
                    "opacity-80 backdrop-blur-sm"
                  )}
                  style={{ height: `${(job.progress / job.duration) * 100}%` }}
                  >
                    <div className="absolute top-0 left-0 right-0 h-[1px] bg-white/50 shadow-[0_0_10px_white]"></div>
                  </div>
                ) : (
                  <div className="flex h-full items-center justify-center text-[10px] text-muted-foreground/20 font-mono rotate-90">
                    IDLE
                  </div>
                )}
              </div>
              
              {job && (
                <div className="absolute top-10 left-0 right-0 text-center">
                  <Badge variant="outline" className="text-[10px] bg-black/50 border-none text-white font-bold">
                    {job.type}
                  </Badge>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>

      <div className="grid gap-4 md:grid-cols-3">
         <Card className="glass-panel cyber-border">
            <CardContent className="p-4 flex items-center gap-4">
               <div className="p-3 rounded bg-red-500/10 text-red-500">
                 <Zap className="w-6 h-6" />
               </div>
               <div>
                 <div className="font-display font-bold">Physics</div>
                 <div className="text-xs text-muted-foreground">Rigid Body Simulation</div>
               </div>
            </CardContent>
         </Card>
         <Card className="glass-panel cyber-border">
            <CardContent className="p-4 flex items-center gap-4">
               <div className="p-3 rounded bg-purple-500/10 text-purple-500">
                 <RotateCcw className="w-6 h-6" />
               </div>
               <div>
                 <div className="font-display font-bold">AI Logic</div>
                 <div className="text-xs text-muted-foreground">Pathfinding & Decision</div>
               </div>
            </CardContent>
         </Card>
         <Card className="glass-panel cyber-border">
            <CardContent className="p-4 flex items-center gap-4">
               <div className="p-3 rounded bg-cyan-500/10 text-cyan-500">
                 <RotateCcw className="w-6 h-6" />
               </div>
               <div>
                 <div className="font-display font-bold">Rendering</div>
                 <div className="text-xs text-muted-foreground">Culling & Command Buffers</div>
               </div>
            </CardContent>
         </Card>
      </div>
    </div>
  );
}