import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Cpu, Move, Eye, Brain, Clock, Zap } from "lucide-react";
import { cn } from "@/lib/utils";

const systems = [
  {
    name: "MovementSystem",
    description: "Velocity/position update prep for Chronos-Physics",
    icon: Move,
    entities: 12405,
    avgTime: 0.0001,
    priority: "High",
    status: "Stable",
    color: "primary"
  },
  {
    name: "BotAISystem",
    description: "Manages bot targeting and firing logic (The Aura Layer)",
    icon: Brain,
    entities: 85,
    avgTime: 0.0003,
    priority: "High",
    status: "Active",
    color: "secondary"
  },
  {
    name: "RenderSystem",
    description: "Gathers Render Components & Culls Invisible Entities",
    icon: Eye,
    entities: 12405,
    avgTime: 0.0001,
    priority: "Normal",
    status: "Stable",
    color: "accent"
  },
  {
    name: "PhysicsSystem",
    description: "Rigid body simulation & collision resolution",
    icon: Zap,
    entities: 4520,
    avgTime: 4.2, // ms
    priority: "Critical",
    status: "Heavy Load",
    color: "destructive"
  }
];

export default function Systems() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-display font-bold text-foreground glow">ECS Architecture</h2>
        <p className="text-muted-foreground font-sans">Hyper-ECS System Performance & Entity Allocation</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {systems.map((sys) => (
          <Card key={sys.name} className="glass-panel cyber-border hover:bg-white/5 transition-colors duration-300 group">
            <CardHeader className="flex flex-row items-start justify-between pb-2">
              <div className="flex items-center gap-3">
                <div className={cn("p-2.5 rounded bg-background border border-white/10 group-hover:border-primary/50 transition-colors")}>
                  <sys.icon className={cn("w-6 h-6", `text-${sys.color}`)} />
                </div>
                <div>
                  <CardTitle className="font-display text-lg">{sys.name}</CardTitle>
                  <CardDescription className="font-sans text-xs mt-1">{sys.description}</CardDescription>
                </div>
              </div>
              <Badge variant="outline" className={cn(
                "font-mono text-[10px] uppercase tracking-wider",
                sys.status === "Heavy Load" ? "border-destructive text-destructive" : "border-green-500 text-green-400"
              )}>
                {sys.status}
              </Badge>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mt-4">
                <div className="bg-black/20 p-3 rounded border border-white/5">
                  <div className="text-[10px] uppercase text-muted-foreground font-mono flex items-center gap-1">
                    <Cpu className="w-3 h-3" /> Entities
                  </div>
                  <div className="text-xl font-display font-bold mt-1">{sys.entities.toLocaleString()}</div>
                </div>
                <div className="bg-black/20 p-3 rounded border border-white/5">
                  <div className="text-[10px] uppercase text-muted-foreground font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" /> Avg Time
                  </div>
                  <div className={cn("text-xl font-display font-bold mt-1", sys.avgTime > 1 ? "text-accent" : "")}>
                    {sys.avgTime < 0.01 ? "< 0.1ms" : `${sys.avgTime}ms`}
                  </div>
                </div>
                <div className="bg-black/20 p-3 rounded border border-white/5">
                  <div className="text-[10px] uppercase text-muted-foreground font-mono">Priority</div>
                  <div className="text-xl font-display font-bold mt-1">{sys.priority}</div>
                </div>
              </div>

              {/* Performance Bar */}
              <div className="mt-4 space-y-1">
                <div className="flex justify-between text-[10px] text-muted-foreground font-mono">
                  <span>Frame Budget Impact</span>
                  <span>{sys.avgTime > 1 ? "HIGH" : "LOW"}</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <div 
                    className={cn("h-full rounded-full", `bg-${sys.color}`)} 
                    style={{ width: `${Math.min((sys.avgTime / 8.33) * 100, 100)}%` }}
                  ></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* ECS Overview Graphic */}
      <Card className="glass-panel cyber-border p-6">
        <CardTitle className="font-display text-lg mb-6">Data-Oriented Design Flow</CardTitle>
        <div className="flex items-center justify-between relative">
          {/* Connecting Line */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-white/10 -z-10"></div>
          
          <div className="bg-card border border-border p-4 rounded-lg z-10 w-48 text-center">
            <div className="text-xs text-muted-foreground uppercase font-mono mb-1">Input</div>
            <div className="font-display font-bold text-primary">Entity Arrays</div>
            <div className="text-[10px] text-muted-foreground mt-2">Contiguous Memory</div>
          </div>

          <div className="bg-card border border-border p-4 rounded-lg z-10 w-48 text-center shadow-[0_0_15px_hsl(var(--primary)/0.2)] border-primary/50">
            <div className="text-xs text-muted-foreground uppercase font-mono mb-1">Process</div>
            <div className="font-display font-bold text-foreground">System Logic</div>
            <div className="text-[10px] text-muted-foreground mt-2">Parallel Execution</div>
          </div>

          <div className="bg-card border border-border p-4 rounded-lg z-10 w-48 text-center">
            <div className="text-xs text-muted-foreground uppercase font-mono mb-1">Output</div>
            <div className="font-display font-bold text-secondary">Component State</div>
            <div className="text-[10px] text-muted-foreground mt-2">Updated Data</div>
          </div>
        </div>
      </Card>
    </div>
  );
}