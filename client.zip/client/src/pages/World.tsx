import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation, Layers, Eye } from "lucide-react";
import { cn } from "@/lib/utils";

const ZONES = {
  'A_CITY_CENTER': { center: [500, 500], size: 100, color: '#06b6d4' },
  'B_FOREST_ZONE': { center: [200, 200], size: 120, color: '#10b981' },
  'C_DESERT_OUTPOST': { center: [800, 300], size: 80, color: '#f59e0b' },
  'D_MOUNTAIN_BASE': { center: [600, 800], size: 150, color: '#8b5cf6' },
};

const MAP_SIZE = 1000;

export default function World() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [playerPos, setPlayerPos] = useState({ x: 500, y: 500 });
  const [lodStates, setLodStates] = useState<Record<string, string>>({});

  // Simulation Loop
  useEffect(() => {
    const interval = setInterval(() => {
      setPlayerPos(prev => {
        // Browninan motion / wander
        const dx = (Math.random() - 0.5) * 20;
        const dy = (Math.random() - 0.5) * 20;
        let newX = Math.max(0, Math.min(MAP_SIZE, prev.x + dx));
        let newY = Math.max(0, Math.min(MAP_SIZE, prev.y + dy));
        return { x: newX, y: newY };
      });
    }, 50);
    return () => clearInterval(interval);
  }, []);

  // Rendering Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Scale
    const scaleX = canvas.width / MAP_SIZE;
    const scaleY = canvas.height / MAP_SIZE;

    // Draw Grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= MAP_SIZE; i += 100) {
      ctx.beginPath();
      ctx.moveTo(i * scaleX, 0);
      ctx.lineTo(i * scaleX, canvas.height);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(0, i * scaleY);
      ctx.lineTo(canvas.width, i * scaleY);
      ctx.stroke();
    }

    // Draw Zones
    const newLodStates: Record<string, string> = {};
    
    Object.entries(ZONES).forEach(([name, data]) => {
      const [cx, cy] = data.center;
      const dist = Math.sqrt(Math.pow(playerPos.x - cx, 2) + Math.pow(playerPos.y - cy, 2));
      
      let lod = "MINIMAL";
      let radiusColor = 'rgba(255, 255, 255, 0.1)';
      
      if (dist < 150) {
        lod = "FULL_DETAIL";
        radiusColor = data.color;
      } else if (dist < 350) {
        lod = "MEDIUM";
        radiusColor = 'rgba(255, 255, 255, 0.3)';
      }
      
      newLodStates[name] = lod;

      // Draw Zone Circle
      ctx.beginPath();
      ctx.arc(cx * scaleX, cy * scaleY, data.size * scaleX, 0, Math.PI * 2);
      ctx.fillStyle = lod === "FULL_DETAIL" ? data.color : 'rgba(255,255,255,0.05)';
      ctx.fill();
      ctx.strokeStyle = data.color;
      ctx.lineWidth = 2;
      ctx.stroke();

      // Draw Label
      ctx.fillStyle = 'white';
      ctx.font = '10px monospace';
      ctx.fillText(name, (cx - 40) * scaleX, (cy - data.size - 10) * scaleY);
    });
    
    setLodStates(newLodStates);

    // Draw Player
    ctx.beginPath();
    ctx.arc(playerPos.x * scaleX, playerPos.y * scaleY, 8, 0, Math.PI * 2);
    ctx.fillStyle = 'white';
    ctx.fill();
    ctx.shadowColor = 'white';
    ctx.shadowBlur = 10;
    
    // Draw View Cone
    ctx.beginPath();
    ctx.moveTo(playerPos.x * scaleX, playerPos.y * scaleY);
    ctx.lineTo((playerPos.x - 30) * scaleX, (playerPos.y - 50) * scaleY);
    ctx.lineTo((playerPos.x + 30) * scaleX, (playerPos.y - 50) * scaleY);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
    ctx.fill();
    ctx.shadowBlur = 0;

    // Draw LOD Rings around player (Visual aid)
    ctx.beginPath();
    ctx.arc(playerPos.x * scaleX, playerPos.y * scaleY, 150 * scaleX, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.setLineDash([5, 5]);
    ctx.stroke();
    ctx.setLineDash([]);

  }, [playerPos]);

  return (
    <div className="grid gap-6 lg:grid-cols-3 h-[calc(100vh-140px)]">
      <Card className="lg:col-span-2 glass-panel cyber-border flex flex-col">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="font-display text-lg flex items-center gap-2">
            <MapPin className="w-5 h-5 text-primary" />
            World Stream Visualizer
          </CardTitle>
          <Badge variant="outline" className="font-mono">1000x1000 Units</Badge>
        </CardHeader>
        <CardContent className="flex-1 p-4 min-h-0">
          <div className="w-full h-full bg-black/40 rounded-lg border border-white/10 relative overflow-hidden">
             <canvas 
               ref={canvasRef} 
               width={800} 
               height={800} 
               className="w-full h-full object-contain"
             />
             <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur px-3 py-2 rounded border border-white/10 text-xs font-mono">
               <div>X: {playerPos.x.toFixed(1)}</div>
               <div>Y: {playerPos.y.toFixed(1)}</div>
             </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card className="glass-panel cyber-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <Layers className="w-5 h-5 text-secondary" />
              Zone LOD States
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(lodStates).map(([name, lod]) => (
              <div key={name} className="bg-white/5 p-3 rounded border border-white/5 flex justify-between items-center">
                <div>
                  <div className="text-xs font-bold text-foreground">{name}</div>
                  <div className="text-[10px] text-muted-foreground font-mono">Size: {ZONES[name as keyof typeof ZONES].size}</div>
                </div>
                <Badge className={cn(
                  "font-mono text-[10px]",
                  lod === "FULL_DETAIL" ? "bg-primary text-primary-foreground" :
                  lod === "MEDIUM" ? "bg-secondary text-secondary-foreground" :
                  "bg-muted text-muted-foreground"
                )}>
                  {lod}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="glass-panel cyber-border">
          <CardHeader>
            <CardTitle className="font-display text-lg flex items-center gap-2">
              <Eye className="w-5 h-5 text-accent" />
              Streaming Metrics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="flex justify-between items-center text-sm">
               <span className="text-muted-foreground">Active Meshes</span>
               <span className="font-mono font-bold">4,231</span>
             </div>
             <div className="flex justify-between items-center text-sm">
               <span className="text-muted-foreground">Memory Usage</span>
               <span className="font-mono font-bold text-primary">1.2 GB</span>
             </div>
             <div className="flex justify-between items-center text-sm">
               <span className="text-muted-foreground">Texture Pool</span>
               <span className="font-mono font-bold">85%</span>
             </div>
             <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden mt-2">
               <div className="h-full bg-accent w-[85%]"></div>
             </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}