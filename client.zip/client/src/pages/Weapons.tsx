import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crosshair, Zap, Shield, Activity, Gauge } from "lucide-react";
import { cn } from "@/lib/utils";

const weapons = [
  {
    id: '01_PLASMA_RIFLE',
    name: 'Plasma Rifle',
    damage: 55.0,
    rpm: 450,
    spread: 0.00,
    mode: 'AUTO',
    projectiles: 1,
    desc: "Standard issue energy weapon. High rate of fire, zero spread.",
    color: "primary"
  },
  {
    id: '02_OMEGA_SHOTGUN',
    name: 'Omega Shotgun',
    damage: 15.0, // Per pellet
    rpm: 90,
    spread: 1.5,
    mode: 'SEMI',
    projectiles: 8,
    desc: "Close quarters devastation. Fires 8 projectiles per shot.",
    color: "destructive"
  },
  {
    id: '03_RAIL_CANNON',
    name: 'Rail Cannon',
    damage: 300.0,
    rpm: 30,
    spread: 0.00,
    mode: 'SINGLE',
    projectiles: 1,
    desc: "Heavy anti-materiel linear accelerator. Extreme damage.",
    color: "secondary"
  },
  {
    id: '04_EMP_GRENADE',
    name: 'EMP Grenade',
    damage: 0.0,
    rpm: 10,
    spread: 0.00,
    mode: 'SINGLE',
    projectiles: 1,
    desc: "Disables electronics and shields in radius. Non-lethal.",
    color: "accent"
  },
];

export default function Weapons() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-display font-bold text-foreground glow">Armory Registry</h2>
        <p className="text-muted-foreground font-sans">Weapon Definitions & Balance Statistics</p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {weapons.map((w) => (
          <Card key={w.id} className="glass-panel cyber-border group hover:-translate-y-1 transition-all duration-300">
            <CardHeader>
              <div className="flex justify-between items-start">
                <Badge variant="outline" className="font-mono text-[10px] border-white/10 text-muted-foreground">
                  {w.id.split('_')[0]}
                </Badge>
                <Badge className={cn(
                  "font-bold tracking-wider",
                  w.mode === 'AUTO' ? "bg-primary text-primary-foreground" :
                  w.mode === 'SEMI' ? "bg-accent text-accent-foreground" :
                  "bg-secondary text-secondary-foreground"
                )}>
                  {w.mode}
                </Badge>
              </div>
              <CardTitle className="font-display text-2xl mt-2">{w.name}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <p className="text-sm text-muted-foreground h-10">{w.desc}</p>
              
              <div className="space-y-3">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono uppercase text-muted-foreground">
                    <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> Damage Potential</span>
                    <span className="text-white">{w.damage * w.projectiles}</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-red-500 rounded-full" style={{ width: `${(w.damage * w.projectiles / 300) * 100}%` }}></div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono uppercase text-muted-foreground">
                    <span className="flex items-center gap-1"><Gauge className="w-3 h-3" /> Fire Rate (RPM)</span>
                    <span className="text-white">{w.rpm}</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-yellow-500 rounded-full" style={{ width: `${(w.rpm / 600) * 100}%` }}></div>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs font-mono uppercase text-muted-foreground">
                    <span className="flex items-center gap-1"><Crosshair className="w-3 h-3" /> Accuracy</span>
                    <span className="text-white">{w.spread === 0 ? "PERFECT" : `${w.spread}°`}</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.max(0, 100 - (w.spread * 20))}%` }}></div>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="border-t border-white/5 pt-4">
              <div className="w-full flex justify-between text-[10px] font-mono text-muted-foreground">
                 <span>PROJ: {w.projectiles}</span>
                 <span>ID: {w.id}</span>
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}