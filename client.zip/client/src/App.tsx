import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/Dashboard";
import Systems from "@/pages/Systems";
import Weapons from "@/pages/Weapons";
import World from "@/pages/World";
import Jobs from "@/pages/Jobs";
import NotFound from "@/pages/not-found";
import { DashboardLayout } from "@/components/layout/DashboardLayout";

function Router() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/systems" component={Systems} />
        <Route path="/weapons" component={Weapons} />
        <Route path="/world" component={World} />
        <Route path="/jobs" component={Jobs} />
        <Route path="/network" component={() => <div className="p-10 text-center font-display text-2xl text-muted-foreground">Network Monitor Under Construction</div>} />
        <Route path="/console" component={() => <div className="p-10 text-center font-display text-2xl text-muted-foreground">Console Under Construction</div>} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;