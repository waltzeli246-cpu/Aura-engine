import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  color?: "primary" | "secondary" | "accent" | "destructive";
  className?: string;
}

export function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  description, 
  trend, 
  trendValue, 
  color = "primary",
  className 
}: StatCardProps) {
  
  const colorClasses = {
    primary: "text-primary border-primary/20 bg-primary/5",
    secondary: "text-secondary border-secondary/20 bg-secondary/5",
    accent: "text-accent border-accent/20 bg-accent/5",
    destructive: "text-destructive border-destructive/20 bg-destructive/5",
  };

  return (
    <Card className={cn("glass-panel cyber-border overflow-hidden", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium font-mono tracking-widest text-muted-foreground uppercase">
          {title}
        </CardTitle>
        <div className={cn("p-2 rounded-full", colorClasses[color])}>
          <Icon className="h-4 w-4" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline space-x-2">
          <div className={cn("text-2xl font-bold font-display tracking-wider text-foreground")}>
            {value}
          </div>
          {trend && (
            <span className={cn(
              "text-xs font-mono", 
              trend === "up" ? "text-green-400" : trend === "down" ? "text-red-400" : "text-muted-foreground"
            )}>
              {trend === "up" ? "▲" : trend === "down" ? "▼" : "−"} {trendValue}
            </span>
          )}
        </div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1 font-sans">{description}</p>
        )}
        
        {/* Decorative Chart Line */}
        <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden flex gap-0.5">
           {Array.from({ length: 10 }).map((_, i) => (
             <div 
               key={i} 
               className={cn("h-full flex-1 rounded-sm opacity-50", colorClasses[color].split(' ')[0].replace('text-', 'bg-'))}
               style={{ opacity: Math.random() * 0.5 + 0.2 }}
             ></div>
           ))}
        </div>
      </CardContent>
    </Card>
  );
}