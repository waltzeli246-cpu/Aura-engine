import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Cpu, 
  Map as MapIcon, 
  Crosshair, 
  Activity, 
  Terminal,
  Settings,
  Zap
} from "lucide-react";
import logo from "@assets/generated_images/futuristic_abstract_logo_for_aura_engine.png";

const navItems = [
  { href: "/", icon: LayoutDashboard, label: "Overview" },
  { href: "/systems", icon: Cpu, label: "ECS Systems" },
  { href: "/world", icon: MapIcon, label: "World Stream" },
  { href: "/weapons", icon: Crosshair, label: "Weaponry" },
  { href: "/jobs", icon: Zap, label: "Job System" },
  { href: "/network", icon: Activity, label: "Network" },
  { href: "/console", icon: Terminal, label: "Console" },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="h-screen w-64 bg-sidebar border-r border-sidebar-border flex flex-col fixed left-0 top-0 z-50">
      <div className="p-6 flex items-center gap-3 border-b border-sidebar-border">
        <img src={logo} alt="Aura Engine" className="w-10 h-10 rounded-sm border border-primary/30 shadow-[0_0_10px_rgba(6,182,212,0.3)]" />
        <div>
          <h1 className="font-display font-bold text-lg tracking-wider text-sidebar-foreground">AURA</h1>
          <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-mono">Engine v0.9.2</p>
        </div>
      </div>

      <nav className="flex-1 py-6 px-3 space-y-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <div className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-all duration-200 group cursor-pointer",
                isActive 
                  ? "bg-sidebar-accent text-primary border-l-2 border-primary shadow-[inset_10px_0_20px_-10px_rgba(6,182,212,0.1)]" 
                  : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
              )}>
                <item.icon className={cn(
                  "w-4 h-4 transition-colors",
                  isActive ? "text-primary drop-shadow-[0_0_3px_rgba(6,182,212,0.5)]" : "text-muted-foreground group-hover:text-foreground"
                )} />
                <span className="font-sans tracking-wide">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <div className="bg-black/30 rounded p-3 border border-white/5">
          <div className="flex justify-between items-center text-xs text-muted-foreground mb-2">
            <span>CPU Load</span>
            <span className="text-primary font-mono">12%</span>
          </div>
          <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-primary w-[12%] shadow-[0_0_5px_hsl(var(--primary))]"></div>
          </div>
          
          <div className="flex justify-between items-center text-xs text-muted-foreground mt-3 mb-2">
            <span>Memory</span>
            <span className="text-secondary font-mono">4.2GB</span>
          </div>
          <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-secondary w-[35%] shadow-[0_0_5px_hsl(var(--secondary))]"></div>
          </div>
        </div>
      </div>
    </div>
  );
}